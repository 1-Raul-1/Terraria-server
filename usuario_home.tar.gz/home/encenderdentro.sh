#!/bin/bash

cd 1449/Linux/

./TerrariaServer.bin.x86_64 -config config.txt
