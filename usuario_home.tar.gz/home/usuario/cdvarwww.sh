#!/bin/bash

cd /var/www/
