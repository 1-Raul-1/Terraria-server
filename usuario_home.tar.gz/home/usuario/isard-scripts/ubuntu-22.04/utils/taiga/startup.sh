#!/bin/bash
docker-compose -f <path>/docker-compose.yml up -d